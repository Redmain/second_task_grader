require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def penalty_per_hour
    penalty_year = 0.00007 * (DateTime.now.year - @reader_with_book.book.published_at) * @reader_with_book.book.price
    penalty_page = 0.000003 * @reader_with_book.book.pages_quantity * @reader_with_book.book.price
    penalty_price = 0.0005 * @reader_with_book.book.price
    penalty = penalty_year + penalty_page + penalty_price
    return penalty 
  end

  def penalty
    current_datetime = DateTime.now
    hour_diff = ((current_datetime - issue_datetime)*24).to_f.floor
    # binding.pry
    return 0 if hour_diff < 0 || @reader_with_book.book.price<=0
    return (self.penalty_per_hour * hour_diff).round 
  end

  def could_meet_each_other? first_author, second_author
    f=(first_author.year_of_birth..first_author.year_of_death) if first_author.year_of_birth<=first_author.year_of_death
    s=(second_author.year_of_birth..second_author.year_of_death) if second_author.year_of_birth<=second_author.year_of_death
    return false if f == nil || s ==nil
    (f.to_set & s.to_set).empty?
  end

  def days_to_buy
    @reader_with_book.book.price == 0 ? 0 : self.penalty_per_hour / @reader_with_book.book.price
  end

  def transliterate author
    m={"А" => "A", "а" => "a","Б" => "B", "б" => "b","В" => "V", "в" => "v","Г" => "H", "г" => "h","Ґ" => "G", "ґ" => "g","Д" => "D", "д" => "d","Е" => "E", "е" => "e","Є" => "Ie","є" => "ie","Ж" => "Zh","ж" => "zh","З" => "Z", "з" => "z","И" => "Y", "и" => "y","І" => "I", "і" => "i","Ї" => "I", "ї" => "i","Й" => "i", "й" => "i","К" => "K", "к" => "k","Л" => "L", "л" => "l","М" => "M", "м" => "m","Н" => "N", "н" => "n","О" => "O", "о" => "o","П" => "P", "п" => "p","Р" => "R", "р" => "r","С" => "S", "с" => "s","Т" => "T", "т" => "t","У" => "U", "у" => "u","Ф" => "F", "ф" => "f","Х" => "Kh", "х" => "kh","Ц" => "Ts", "ц" => "ts","Ч" => "Ch", "ч" => "ch","Ш" => "Sh", "ш" => "sh","Щ" => "Shch", "щ" => "shch","Ю" => "Iu", "ю" => "iu","Я" => "Ia", "я" => "ia","Ь" => "", "ь" => ""}

    mm={"А" => "A", "а" => "a","Б" => "B", "б" => "b","В" => "V", "в" => "v","Г" => "H", "г" => "h","Ґ" => "G", "ґ" => "g","Д" => "D", "д" => "d","Е" => "E", "е" => "e","Є" => "Ye", "є" => "ye","Ж" => "Zh", "ж" => "zh","З" => "Z", "з" => "z","И" => "Y", "и" => "y","І" => "I", "і" => "i","Ї" => "Yi", "ї" => "yi","Й" => "Y", "й" => "y","К" => "K", "к" => "k","Л" => "L", "л" => "l","М" => "M", "м" => "m","Н" => "N", "н" => "n","О" => "O", "о" => "o","П" => "P", "п" => "p","Р" => "R", "р" => "r","С" => "S", "с" => "s","Т" => "T", "т" => "t","У" => "U", "у" => "u","Ф" => "F", "ф" => "f","Х" => "Kh", "х" => "kh","Ц" => "Ts", "ц" => "ts","Ч" => "Ch", "ч" => "ch","Ш" => "Sh", "ш" => "sh","Щ" => "Shch", "щ" => "shch","Ю" => "Yu", "ю" => "yu","Я" => "Ya", "я" => "ya","Ь" => "", "ь" => ""}

    author.name.chars.map.with_index do |c,i|
    if i==0 || author.name[i-1]==' ' 
      if mm.has_key?c then mm.fetch(c) else c end
      else
      if m.has_key?c then m.fetch(c) else c end
    end    
    end.join()

  end

  def penalty_to_finish
    current_datetime = DateTime.now
    hour_diff = ((current_datetime - issue_datetime)*24).to_f.floor + @reader_with_book.time_to_finish

    penalty_in_cents = (self.penalty_per_hour * hour_diff).round
    # binding.pry
    penalty_in_cents < 0 || self.penalty_per_hour < 0 ? 0 : penalty_in_cents 
  end

  def email_notification_params
      {
        penalty: "some code",
        hours_to_deadline: "some code",
      }
  end

  def email_notification
"Hello, #{self.email_notification_params[:penalty]}!

You should return a book \"some code\" authored by some code in some code hours.
Otherwise you will be charged $some code per hour. 
"
  end

end
