require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end
  



  def penalty

   hours_overdue = ((Time.now.to_i - issue_datetime.to_i) / 3600)  # время на которое уже опоздал
    if (reader_with_book.penalty hours_overdue) < 0
      return  0
    else
      return reader_with_book.penalty hours_overdue
    end

  
  end


  def could_meet_each_other? first_author, second_author
   #p second_author.year_of_birth

   if first_author.year_of_birth >= second_author.year_of_birth  && first_author.year_of_birth <= second_author.year_of_death
     return  true
  elsif second_author.year_of_birth >= first_author.year_of_birth && second_author.year_of_birth <= first_author.year_of_death
    return  true
  else
     return  false
  end

  end

  def days_to_buy
  
   penya_for_day = reader_with_book.book.penalty_per_hour * 24
   dni = reader_with_book.book.price / penya_for_day
   if dni>0
   return   dni.round
  else
    return   0
  end
  end

  def transliterate author
  replace = {

        "а" => "a",   "б" => "b",   "в" => "v",
        "г" => "h",   "д" => "d",   "е" => "e",   "є" => "ie",
        "ж" => "zh",  "з" => "z",   "і" => "i",
        "и" => "y",   "й" => "i",   "к" => "k",   "ї" => "i",
        "л" => "l",   "м" => "m",   "н" => "n",   "ґ" => "g",
        "о" => "o",   "п" => "p",   "р" => "r",
        "с" => "s",   "т" => "t",   "у" => "u",
        "ф" => "f",   "х" => "kh",  "ц" => "ts",
        "ч" => "ch",  "ш" => "sh",  "щ" => "shch",
        "ю" => "iu",  "я" => "ia",

        "А" => "A",   "Б" => "B",   "В" => "V",
        "Г" => "H",   "Д" => "D",   "Е" => "E",   "Є" => "Ye",
        "Ж" => "Zh",  "З" => "Z",   "І" => "I",
        "И" => "Y",   "Й" => "Y",   "К" => "K",   "Ї" => "Yi",
        "Л" => "L",   "М" => "M",   "Н" => "N",   "Ґ" => "G",
        "О" => "O",   "П" => "P",   "Р" => "R",
        "С" => "S",   "Т" => "T",   "У" => "U",
        "Ф" => "F",   "Х" => "Kh",  "Ц" => "Ts",
        "Ч" => "Ch",  "Ш" => "Sh",  "Щ" => "Shch",
        "Ю" => "Yu",  "Я" => "Ya",

    }

    replace.each do |key, value|
      author.name.gsub!(key, value)
    end
    return  author.name.to_s
  end



  def penalty_to_finish
   
   date_now = DateTime.now.new_offset
   days_left = issue_datetime - date_now #осталось дней до сдачи
   hours_left = days_left *24        #осталось часов до сдачи
   time_needed = reader_with_book.time_to_finish # часы, необходимые на прочтение
   hours = time_needed - hours_left  # лишние часы
    puts time_needed
   if hours > 0 
      total_penya = hours*reader_with_book.book.penalty_per_hour
      total_penya = total_penya.round
      return  total_penya
      
    else
     
        return  0
      
    end
   

  end


=begin
  # this is a placeholder. Just ignore it for the moment.
  def email_notification_params

 {

penalty: ((reader_with_book.book.penalty_per_hour + 0.005)* 100).to_i / 100.0,
hours_to_deadline: ((issue_datetime.to_i - Time.now.to_i) / 3600) ,
reader_name: reader_with_book.name ,  
book_tit: reader_with_book.book.title ,   
book_aut: reader_with_book.book.author.name

 }



  end


 
def email_notification
#use email_notification_params

  email_notification_params[:penalty] 
  <<-TEXT
    Hello, #{email_notification_params[:reader_name]}!

    We remind you that you should return the book "#{email_notification_params[:book_tit]}" authored by #{email_notification_params[:book_aut] } in  #{email_notification_params[:hours_to_deadline]} hours.

    Otherwise you will be charged ¢ #{email_notification_params[:penalty]} per hour.
    
    TEXT

end
=end


end





