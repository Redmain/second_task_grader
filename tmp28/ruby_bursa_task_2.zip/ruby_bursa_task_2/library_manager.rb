require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'


class LibraryManager
  @@PUB_RATE =  0.00007
  @@PAGES_RATE = 0.000003
  @@CONST_RATE = 0.0005

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def hour_rate
    pub_rate = @@PUB_RATE * @reader_with_book.book.age
    pages_rate = @@PAGES_RATE * @reader_with_book.book.pages_quantity
    pub_rate + pages_rate + @@CONST_RATE
  end

  def penalty
    issue_exceed = (DateTime.now.new_offset(0) - @issue_datetime).to_f * 24
    res =  hour_rate * @reader_with_book.book.price * issue_exceed
    res > 0 ? res.round : 0
  end

  def could_meet_each_other? first_author, second_author
    first_author.can_meet? second_author
  end

  def days_to_buy
    (1/hour_rate/24).ceil
  end

  def transliterate author
    author.name_translit
  end

  def penalty_to_finish
    exp = DateTime.now.new_offset(0) + @reader_with_book.time_to_finish/24.0
    res = (@reader_with_book.book.price * hour_rate * (exp - @issue_datetime)*24)
    res > 0 ? res.round : 0
  end

  private :hour_rate

  def email_notification_params
      {
        penalty: "#{(hour_rate*@reader_with_book.book.price).round/100.0}",
        hours_to_deadline: "#{ 
          x = (@issue_datetime - DateTime.now.new_offset(0)).to_f * 24
          x > 0 ? x.round : 0
          }"
      }
  end

  def email_notification
<<-TEXT
Hello, #{@reader_with_book.name}!

You should return a book "#{@reader_with_book.book.title}" authored by #{@reader_with_book.book.author.name} in #{email_notification_params[:hours_to_deadline]} hours.

Otherwise you will be charged $#{email_notification_params[:penalty]} per hour.
TEXT
  end

end
