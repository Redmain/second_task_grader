require 'active_support/all'
require 'pry'


require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'
class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end


  def penalty


    hours_overdue = ((Time.now.to_i - issue_datetime.to_i) / 3600)
    if reader_with_book.penalty(hours_overdue) > 0
      return reader_with_book.penalty hours_overdue
    else
      return 0
    end


  end

  def could_meet_each_other? first_author, second_author


    if ((first_author.year_of_birth - second_author.year_of_death) * (second_author.year_of_birth - first_author.year_of_death)) >= 0
      true

    else

      false

    end

  end

  def days_to_buy

    if reader_with_book.book.price != 0
    ((reader_with_book.book.price / reader_with_book.book.penalty_per_hour) / 24).round
    else
     return 0
      end

  end

  def transliterate author
    replace = {

        "а" => "a", "б" => "b", "в" => "v",
        "г" => "h", "д" => "d", "е" => "e", "є" => "ie",
        "ж" => "zh", "з" => "z", "і" => "i",
        "и" => "y", "й" => "i", "к" => "k", "ї" => "i",
        "л" => "l", "м" => "m", "н" => "n", "ґ" => "g",
        "о" => "o", "п" => "p", "р" => "r",
        "с" => "s", "т" => "t", "у" => "u",
        "ф" => "f", "х" => "kh", "ц" => "ts",
        "ч" => "ch", "ш" => "sh", "щ" => "shch",
        "ю" => "iu", "я" => "ia",

        "А" => "A", "Б" => "B", "В" => "V",
        "Г" => "H", "Д" => "D", "Е" => "E", "Є" => "Ye",
        "Ж" => "Zh", "З" => "Z", "І" => "I",
        "И" => "Y", "Й" => "Y", "К" => "K", "Ї" => "Yi",
        "Л" => "L", "М" => "M", "Н" => "N", "Ґ" => "G",
        "О" => "O", "П" => "P", "Р" => "R",
        "С" => "S", "Т" => "T", "У" => "U",
        "Ф" => "F", "Х" => "Kh", "Ц" => "Ts",
        "Ч" => "Ch", "Ш" => "Sh", "Щ" => "Shch",
        "Ю" => "Yu", "Я" => "Ya",

    }

    replace.each do |key, value|
      author.name.gsub!(key, value)
    end
    return author.name.to_s


  end

  def penalty_to_finish

    date_now = DateTime.now.new_offset(0)

    if date_now.to_time <= issue_datetime

      hours_left = ((issue_datetime.to_i - Time.now.to_i).round / 3600)

      penalty = hours_left - reader_with_book.time_to_finish

      if penalty >= 0
        return 0
      else
        penalty_price = reader_with_book.penalty(reader_with_book.time_to_finish - hours_left).round
      end
    else
      hours_left = ((Time.now.to_i - issue_datetime.to_i) / 3600)

      penalty_price = reader_with_book.penalty(reader_with_book.time_to_finish + hours_left).round
    end


  end


#   def email_notification
#
#     <<-TEXT
#     Hello, #{email_notification_params[:reader_name]}
#
# You should return a book #{email_notification_params[:book_title]} authored by "#{email_notification_params[:book_author]}" in  #{email_notification_params[:time_left]} hours.
#
# Otherwise you will be charged $#{email_notification_params[:penalty_per_hour]} per hour.
#     TEXT
#
#   end
#
#   def email_notification_params
#
#     {
#         reader_name: reader_with_book.name,
#         book_title: reader_with_book.book.title,
#         book_author: reader_with_book.book.author.name,
#         time_left: ((issue_datetime.to_i - Time.now.to_i) / 3600),
#         penalty_per_hour: sprintf("%.2f", ((reader_with_book.book.penalty_per_hour) / 100)).to_f
#
#     }
#
#   end

end

#
# leo_tolstoy = Author.new(1828, 1910, 'Leo Tolstoy')
# oscar_wilde = Author.new(1854, 1900, 'Oscar Wilde')
# ukrainan_author = Author.new(1856, 1916, 'Іван Франко')
#
# war_and_peace = PublishedBook.new(leo_tolstoy, 'War and Peace', 1400, 3280, 1996)
# ivan_testenko = ReaderWithBook.new('Ivan Testenko', 16, war_and_peace, 328)
# manager = LibraryManager.new(ivan_testenko, (DateTime.now.new_offset(0) - 2.days))
#
# #
# #  p manager.penalty
# # p manager.could_meet_each_other? leo_tolstoy, oscar_wilde
# # p manager.days_to_buy
# # p manager.transliterate ukrainan_author
# # p manager.penalty_to_finish

#  manager.email_notification_params
# p manager.email_notification