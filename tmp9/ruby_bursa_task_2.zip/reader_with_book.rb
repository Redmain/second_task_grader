class ReaderWithBook < Reader
  attr_accessor :book, :current_page

  def initialize name, reading_speed, book, current_page
    @book = book
    @current_page = current_page
    super name, reading_speed
  end

  def time_to_finish

    ((book.pages_quantity.to_f - current_page.to_f) / reading_speed.to_f).ceil

  end

  def penalty hours

    (book.penalty_per_hour * hours).round

  end

end
