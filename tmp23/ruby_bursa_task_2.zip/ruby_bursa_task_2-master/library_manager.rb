require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def penalty
    @reader_with_book.book.penalty(@issue_datetime)
  end

  def could_meet_each_other? first_author, second_author
    first_author.can_meet?(second_author)
  end

  def days_to_buy
    @reader_with_book.book.days_to_buy
  end

  def transliterate author
    author.transliterate
  end

  def penalty_to_finish
    @reader_with_book.penalty_to_finish(@issue_datetime)
  end

  def email_notification_params
      {
        reader: @reader_with_book.name,
        book: @reader_with_book.book.title,
        author: @reader_with_book.book.author.transliterate,
        hours_to_deadline: @reader_with_book.hours_to_deadline(@issue_datetime),
        penalty: @reader_with_book.book.price_per_hour        
      }
  end

  def email_notification
    params = email_notification_params
    <<-TEXT
Hello, #{params[:reader]}!

You should return a book #{params[:book]} authored by #{params[:author]} in #{params[:hours_to_deadline]} hours.
Otherwise you will be charged #{params[:penalty]} per hour. 
TEXT
  end

end
