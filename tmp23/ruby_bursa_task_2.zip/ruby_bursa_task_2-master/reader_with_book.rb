class ReaderWithBook < Reader
  attr_accessor :book, :current_page

  def initialize  name, reading_speed, book, current_page
    @book = book
    @current_page = current_page
    super name, reading_speed
  end 

  #статок времени в часах
  def time_to_finish
    (@book.pages_quantity - @current_page) / @reading_speed
  end

  def penalty_to_finish issue_datetime
  	current = DateTime.now.new_offset(0)
    return 0 if @book.price <= 0 || @book.pages_quantity <= 0 || @current_page <= 0 || (@book.pages_quantity - @current_page) <= 0

    #Нужно на прочтение в секундах
    left_seconds = time_to_finish * 3600

    #Дата завршения чтения
    left_time = current.to_time + left_seconds

    return 0 if issue_datetime >= left_time

    #Сколько часов перечитывает с момента сдачи
    total_hours = (left_time - issue_datetime.to_time).to_i / 3600

    #тоговая пеня за превышение даты сдачи
    total_peny = (total_hours * @book.price_per_hour).round
  end

  def hours_to_deadline(issue_datetime, current = DateTime.now.new_offset(0))    
    (current.to_time - issue_datetime.to_time).to_i / 3600
  end
end
