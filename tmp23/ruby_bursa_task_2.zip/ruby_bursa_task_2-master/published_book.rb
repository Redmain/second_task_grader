class PublishedBook < Book
  attr_accessor :price, :pages_quantity, :published_at

  def initialize author, title, price, pages_quantity, published_at
    @price = price
    @pages_quantity = pages_quantity
    @published_at = published_at
    super author, title
  end

  def price_per_hour
  	( 0.00007 * (DateTime.now.year - @published_at) * @price) +
    (0.000003 * @pages_quantity * @price) + (0.0005 * @price)  	
  end

  def penalty issue_datetime
  	current = DateTime.now.new_offset(0)
    return 0 if @price <= 0 || issue_datetime >= current 

    total_hours = (current.to_time - issue_datetime.to_time).to_i / 3600
    total_peny = (total_hours * price_per_hour).round

    return total_peny
  end

  def days_to_buy
  	return 0 if @price <= 0
    return (@price / price_per_hour / 24).round
  end
end
