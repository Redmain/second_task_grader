require 'active_support/all'
require 'pry'

require './library_manager.rb'
require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def penalty_for_hour published_book
      return published_book.price * ( 0.00007 * (DateTime.now.year - 1 - published_book.published_at) + 0.000003 * published_book.pages_quantity + 0.0005)
  end

  def penalty
    hours_passed =  ((DateTime.now - issue_datetime).to_f * 24).round
    if hours_passed > 0 
        hours_passed * penalty_for_hour(reader_with_book.book)
    else 
       return 0              
    end
  end
  

 
  def could_meet_each_other? first_author, second_author

    return first_author.can_meet?(second_author)
  
  end

  def days_to_buy
    penaltyHours = reader_with_book.book.price / penalty_for_hour(reader_with_book.book)
    return (penaltyHours / 24).round
  end

  def transliterate author
    name = author.name.split[0]
    surname = author.name.split[1]
    letters = {
        "а" => "a",   "б" => "b",   "в" => "v",
        "г" => "h",   "д" => "d",   "е" => "e",   "є" => "ie",
        "ж" => "zh",  "з" => "z",   "і" => "i",
        "и" => "y",   "й" => "i",   "к" => "k",   "ї" => "i",
        "л" => "l",   "м" => "m",   "н" => "n",   "ґ" => "g",
        "о" => "o",   "п" => "p",   "р" => "r",
        "с" => "s",   "т" => "t",   "у" => "u",
        "ф" => "f",   "х" => "kh",  "ц" => "ts",
        "ч" => "ch",  "ш" => "sh",  "щ" => "shch",
        "ю" => "iu",  "я" => "ia",

        "А" => "A",   "Б" => "B",   "В" => "V",
        "Г" => "H",   "Д" => "D",   "Е" => "E",   "Є" => "Ye",
        "Ж" => "Zh",  "З" => "Z",   "І" => "I",
        "И" => "Y",   "Й" => "Y",   "К" => "K",   "Ї" => "Yi",
        "Л" => "L",   "М" => "M",   "Н" => "N",   "Ґ" => "G",
        "О" => "O",   "П" => "P",   "Р" => "R",
        "С" => "S",   "Т" => "T",   "У" => "U",
        "Ф" => "F",   "Х" => "Kh",  "Ц" => "Ts",
        "Ч" => "Ch",  "Ш" => "Sh",  "Щ" => "Shch",
        "Ю" => "Yu",  "Я" => "Ya",
    }

    a = name.gsub(/#{letters.keys}/, letters) + ' ' + surname.gsub(/#{letters.keys}/, letters)
    puts a
    return a
  end

  def penalty_to_finish
    time_now = DateTime.now.new_offset(0)
    time_till_read = (reader_with_book.time_to_finish / 24.to_f)
    fin_time = DateTime.now + time_till_read

    #res = if finishtime > issue_datetime


    res = fin_time > issue_datetime ? penalty_for_hour(reader_with_book.book) * 0.001 * ((fin_time - issue_datetime).to_f * 24).round : 0
    return res.round

  end

  def email_notification_params
      {
        penalty: penalty_for_hour(reader_with_book.book),
        hours_to_deadline: (((issue_datetime - DateTime.now).to_f * 24).round).abs,
      }
  end

  def email_notification
    #use email_notification_params
    return "Hello, #{reader_with_book.name}!

You should return a book #{reader_with_book.book.title} authored by #{reader_with_book.book.author.name} in #{email_notification_params[:hours_to_deadline]} hours.
Otherwise you will be charged #{email_notification_params[:penalty]} per hour.
"
  end

end