class Author
  attr_accessor :year_of_birth, :year_of_death, :name

  def initialize year_of_birth, year_of_death, name
    @year_of_birth = year_of_birth
    @year_of_death = year_of_death
    @name = name
  end

  def can_meet? other_author
    lifetime1 = (@year_of_birth..@year_of_death).to_a
    lifetime2 = (other_author.year_of_birth..other_author.year_of_death).to_a
    (lifetime1 & lifetime2).length >= 1 ? true : false
  end

end
