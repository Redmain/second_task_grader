require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def penalty
    hours_overdue = ((DateTime.now.utc.to_i - issue_datetime.to_time.to_i) / 3600)

    reader_with_book.penalty * hours_overdue
  end

  def could_meet_each_other? first_author, second_author
    first_author.can_meet? second_author
  end

  def days_to_buy
    (PublishedBook.price / (PublishedBook.price * 0.001 * 24)).round
  end

  def transliterate author
    
    trans = author.name
    
    u_a = ['А', 'а', 'Б', 'б', 'В', 'в', 'Г', 'г', 'Ґ', 'ґ', 'Д', 'д', 'Е', 'е',
                  'Є', 'є', 'Ж', 'ж', 'З', 'з', 'И', 'и', 'І', 'і', 'Ї', 'ї', 'Й', 'й',
                  'К', 'к', 'Л', 'л', 'М', 'м', 'Н', 'н', 'О', 'о', 'П', 'п', 'Р', 'р',
                  'С', 'с', 'Т', 'т', 'У', 'у', 'Ф', 'ф', 'Х', 'х', 'Ц', 'ц',
                  'Ч', 'ч', 'Ш', 'ш', 'Щ', 'щ', 'Ь', 'ь', 'Ю', 'ю', 'Я', 'я']
    e_a = ['A', 'a', 'B', 'b', 'V', 'v', 'H', 'h', 'G', 'g', 'D', 'd', 'E', 'e',
                  'Ye', 'ie', 'Zh', 'zh', 'Z', 'z', 'Y', 'y', 'I', 'i', 'Yi', 'i', 'Y', 'i',
                  'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'R', 'r',
                  'S', 's', 'T', 't', 'U', 'u', 'F', 'f', 'Kh', 'kh', 'Ts', 'ts',
                  'Ch', 'ch', 'Sh', 'sh', 'Shch', 'shch', '', '', 'Yu', 'iu', 'Ya', 'ia']
    
    for i in 0..u_a.length-1
      
    trans = trans.gsub(u_a[i], e_a[i])
    
    return trans
  end

  def penalty_to_finish

    finish_time = DateTime.now.new_offset(0) + reader_with_book.time_to_finish / 24
    time_over = ((finish_time - issue_datetime).to_f * 24).round
    if finish_time > issue_datetime
    penalty_to_finish = time_over * penalty_per_hour 
    else
    penalty_to_finish = 0
  end  

  end

  # this is a placeholder. Just ignore it for the moment.
  def email_notification_params

  end

end
