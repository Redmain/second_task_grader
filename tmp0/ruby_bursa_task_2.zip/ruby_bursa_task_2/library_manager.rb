require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end


  def penalty
   expired_hours = ((Time.now.utc.to_i - issue_datetime.to_time.to_i) / 3600.0).ceil
    penalty_in_cents = reader_with_book.penalty  expired_hours
    if penalty_in_cents < 0 || reader_with_book.book_price < 0 
      0 
    else
      penalty_in_cents
    end 
  end


  def days_to_buy
    (1.0 / (24.0 * reader_with_book.book_penalty_per_hour / reader_with_book.book_price)).ceil
  end

  def transliterate author
    author.transliterate author
  end


  def penalty_to_finish
    time_to_finish = reader_with_book.time_to_finish
    expired_hours = ((Time.now.utc.to_i - issue_datetime.to_time.to_i) / 3600.0 + time_to_finish).ceil
    penalty_in_cents = reader_with_book.penalty expired_hours
    if penalty_in_cents < 0 || reader_with_book.book_price < 0 
      0 
    else
      penalty_in_cents
    end   
  end

  def email_notification_params
      {
        penalty: "some code",
        hours_to_deadline: "some code",
      }
  end

  def email_notification
    #use email_notification_params
  end

end
