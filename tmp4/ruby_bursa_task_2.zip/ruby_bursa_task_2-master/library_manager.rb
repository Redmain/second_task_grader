require 'active_support/all'
require 'pry'

require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'

class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end


  def penalty  
    now_datetime = DateTime.now.new_offset.strftime('%s').to_f
    old_datetime = issue_datetime.strftime('%s').to_f
    delta_hour_for_pen = (now_datetime - old_datetime)/3600
    price = self.reader_with_book.book.price
    all_pages = self.reader_with_book.book.pages_quantity
    year_now = DateTime.now.new_offset.strftime('%Y').to_i
    year_publish = self.reader_with_book.book.published_at
    delta_years_book = year_now - year_publish

    pen_for_hour = ( 0.00007 * delta_years_book * price) + (0.000003 * all_pages * price) + (0.0005 * price)

    delta_hour_for_pen > 0 ? (pen_for_hour * delta_hour_for_pen).round : 0 
  end


  def could_meet_each_other? first_author, second_author
    first = (first_author.year_of_birth..first_author.year_of_death).to_a
    second = (second_author.year_of_birth..second_author.year_of_death).to_a
    
    (first & second).length >= 1 ? true : false
  end


  def days_to_buy
    price = self.reader_with_book.book.price
    all_pages = self.reader_with_book.book.pages_quantity
    year_now = DateTime.now.new_offset.strftime('%Y').to_i
    year_publish = self.reader_with_book.book.published_at
    delta_years_book = year_now - year_publish

    pen_for_hour = ( 0.00007 * delta_years_book * price) + (0.000003 * all_pages * price) + (0.0005 * price)

    (price / (24 * pen_for_hour)).to_i + 1
  end


  def transliterate author
    en_name = ''
    alphabet_ua = ['А', 'а', 'Б', 'б', 'В', 'в', 'Г', 'г', 'Ґ', 'ґ', 'Д', 'д', 'Е', 'е', 'Є', 'є', 'Ж', 'ж', 'З', 'з',
               'И', 'и', 'І', 'і', 'Ї', 'ї', 'Й', 'й', 'К', 'к', 'Л', 'л', 'М', 'м', 'Н', 'н', 'О', 'о', 'П', 'п',
               'Р', 'р', 'С', 'с', 'Т', 'т', 'У', 'у', 'Ф', 'ф', 'Х', 'х', 'Ц', 'ц', 'Ч', 'ч', 'Ш', 'ш', 'Щ', 'щ',
               'Ю', 'ю', 'Я', 'я', ' ', '-', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', "'"]
    translit_en = ['A', 'a', 'B', 'b', 'V', 'v', 'H', 'h', 'G', 'g', 'D', 'd', 'E', 'e', 'Ye', 'ie', 'Zh', 'zh', 'Z', 'z',
               'Y', 'y', 'I', 'i', 'Yi', 'i', 'Y', 'i', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p',
               'R', 'r', 'S', 's', 'T', 't', 'U', 'u', 'F', 'f', 'Kh', 'kh', 'Ts', 'ts', 'Ch', 'ch', 'Sh', 'sh', 'Shch', 'shch',
               'Yu', 'iu', 'Ya', 'ia', ' ', '-', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', "'"]

    author.name.each_char {|var| en_name << translit_en.fetch(alphabet_ua.index(var))}
    en_name
  end


  def penalty_to_finish
    now_datetime = DateTime.now.new_offset.strftime('%s').to_f
    old_datetime = issue_datetime.strftime('%s').to_f
    delta_hour = (old_datetime - now_datetime) / 3600
    price = self.reader_with_book.book.price
    pages_quantity_new = self.reader_with_book.book.pages_quantity
    current_page_new = self.reader_with_book.current_page
    reading_speed_new = self.reader_with_book.reading_speed
    rest_hours = (pages_quantity_new - current_page_new) / reading_speed_new

     if delta_hour > 0 
      (delta_hour - rest_hours) > 0 ? 0 : ((delta_hour - rest_hours).abs * price * 0.001).round
    else
      ((delta_hour * price * 0.001).abs + rest_hours * price * 0.001).round
    end
  end


  # this is a placeholder. Just ignore it for the moment.
  def email_notification_params
  end
end
