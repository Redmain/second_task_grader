class Author
  attr_accessor :year_of_birth, :year_of_death, :name

  def initialize year_of_birth, year_of_death, name
    @year_of_birth = year_of_birth
    @year_of_death = year_of_death
    @name = name
  end

  def can_meet? other_author

  	lifetime1 = year_of_death - year_of_birth 
    lifetime2 = other_author.year_of_death - other_author.year_of_birth 
    
    case
      when year_of_death < other_author.year_of_birth 
        return false
      when other_author.year_of_death < year_of_birth 
        return false
      when lifetime1 < 0
        return false
      when lifetime2 < 0
        return false
      when year_of_birth > other_author.year_of_birth
        if other_author.year_of_birth < year_of_death
          return true
        end
      when other_author.year_of_birth > year_of_birth
        if year_of_birth < other_author.year_of_death
          return true
        end
      when year_of_death == other_author.year_of_death && year_of_birth == other_author.year_of_birth
        return true
    end
  	
  end

  def author_translit 
  	 h = { 
  	     	 "А" => "A", "а" => "a",
		     "Б" => "B", "б" => "b",
		     "В" => "V", "в" => "v",
		     "Г" => "H", "г" => "h",
		     "Ґ" => "G", "ґ" => "g",
		     "Д" => "D", "д" => "d",
		     "Е" => "E", "е" => "e",
		     "Є" => "Ye", "є" => "ie",
		     "Ж" => "Zh", "ж" => "zh",
		     "З" => "Z", "з" => "z",
		     "И" => "Y", "и" => "y",
		     "І" => "I", "і" => "i",
		     "Ї" => "Yi", "ї" => "i",
		     "Й" => "Y", "й" => "i",
		     "К" => "K", "к" => "k",
		     "Л" => "L", "л" => "l",
		     "М" => "M", "м" => "m",
		     "Н" => "N", "н" => "n",
		     "О" => "O", "о" => "o",
		     "П" => "P", "п" => "p",
		     "Р" => "R", "р" => "r",
		     "С" => "S", "с" => "s",
		     "Т" => "T", "т" => "t",
		     "У" => "U", "у" => "u",
		     "Ф" => "F", "ф" => "f",
		     "Х" => "Kh", "х" => "kh",
		     "Ц" => "Ts", "ц" => "ts",
		     "Ч" => "Ch", "ч" => "ch",
		     "Ш" => "Sh", "ш" => "sh",
		     "Щ" => "Shch", "щ" => "shch",
		     "Ю" => "Yu", "ю" => "iu",
		     "Я" => "Ya", "я" => "ia" 
        }
        name.gsub(/[АаБбВвГгҐґДдЕеЄєЖжЗзИиІіЇїЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЮюЯя]/, h)  	
  end


end
