class LibraryManager

  attr_accessor :reader_with_book, :issue_datetime

  def initialize reader_with_book, issue_datetime
    @reader_with_book = reader_with_book
    @issue_datetime = issue_datetime
  end

  def hours_overdue
    (Time.now.utc.to_i - issue_datetime.to_time.to_i)/3600
  end


  def penalty

    puts reader_with_book.penalty(hours_overdue)

  end

  def could_meet_each_other? first_author, second_author

    puts first_author.can_meet?(second_author)

  end

  def days_to_buy

    puts reader_with_book.buy_book

  end

  def transliterate author 
      
    puts author.author_translit         

  end

  def penalty_to_finish

    puts reader_with_book.penalty_finish_book(hours_overdue)

  end

end
