class ReaderWithBook < Reader
  attr_accessor :amazing_book, :current_page

  def initialize  name, reading_speed, amazing_book, current_page
    @amazing_book = amazing_book
    @current_page = current_page
    super name, reading_speed
  end 

  def time_to_finish
    (amazing_book.pages_quantity - current_page) / reading_speed
  end

  def penalty hours
  	(amazing_book.penalty_per_hour * hours).round
  end

  def buy_book
  	amazing_book.days_to_buy_book
  end

  def penalty_finish_book hours_overdue
    
    left_pages_to_read = amazing_book.pages_quantity - current_page
    return 0 if reading_speed <= 0 || left_pages_to_read < 0
    amazing_book.complex_penalty(hours_overdue, time_to_finish)    
    
  end

end
