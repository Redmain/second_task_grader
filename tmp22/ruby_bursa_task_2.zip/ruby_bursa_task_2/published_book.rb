class PublishedBook < Book
  attr_accessor :price, :pages_quantity, :published_at

  def initialize author, title, price, pages_quantity, published_at
    @price = price
    @pages_quantity = pages_quantity
    @published_at = published_at
    super author, title
  end

  def age 
  Time.now.year - published_at - 1 
  end


  def penalty_per_hour

    price_penalty = price * 0.0005
    pages_penalty = 0.000003 * price * pages_quantity     
    age_penalty = 0.00007 * price * age        
    price_penalty + pages_penalty + age_penalty
  	
  end

  def days_to_buy_book

  	hour = 0.0
    var = price * 1.0
    loop do 
      var -= penalty_per_hour
      hour += 1.0
      break if var <= 0
    end
    (hour/24).round
  	
  end

  def complex_penalty hours_overdue, time_to_finish

    if hours_overdue > 0
       ((hours_overdue + time_to_finish) * penalty_per_hour).round
      else 
        hours_overdue = hours_overdue * (-1)
        if hours_overdue > time_to_finish
          return 0
        else ((time_to_finish - hours_overdue) * penalty_per_hour).round
        end
    end
    
  end

end
